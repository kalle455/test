import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext.jsx'

export default function Login() {
  const { login } = useApp()
  const navigate = useNavigate()
  const [username, setUsername] = useState('')
  const [error, setError] = useState('')

  const submit = (e) => {
    e.preventDefault()
    const res = login(username)
    if (!res.ok) { setError(res.error); return }
    navigate('/')
  }

  return (
    <div style={styles.wrap}>
      <div className="glass" style={styles.panel}>
        <div className="eyebrow" style={{ marginBottom: 8 }}>Zutritt zum Empire</div>
        <h1 style={{ fontSize: 30, marginBottom: 8 }}>Anmelden</h1>
        <p style={{ color: 'var(--muted)', fontSize: 13.5, marginBottom: 28, lineHeight: 1.6 }}>
          Gib einen Benutzernamen ein. Existiert er bereits, wirst du angemeldet — andernfalls wird automatisch ein neues Konto erstellt.
        </p>
        <form onSubmit={submit}>
          <div className="field">
            <label>Benutzername</label>
            <input autoFocus value={username} onChange={(e) => setUsername(e.target.value)} placeholder="z. B. DuelistKing" />
          </div>
          {error && <div style={{ color: 'var(--danger)', fontSize: 13, marginBottom: 14 }}>{error}</div>}
          <button className="btn btn-gold" type="submit" style={{ width: '100%' }}>Weiter</button>
        </form>
        <div style={{ marginTop: 20, fontSize: 12, color: 'var(--muted)', textAlign: 'center' }}>
          Admin-Zugang: Benutzername <b style={{ color: 'var(--gold)' }}>Kalenski</b>
        </div>
      </div>
    </div>
  )
}

const styles = {
  wrap: { display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '75vh', padding: 40 },
  panel: { width: 440, padding: 40 },
}

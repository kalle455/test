import React, { useState } from 'react'
import { useSearchParams, Navigate } from 'react-router-dom'
import { useApp } from '../context/AppContext.jsx'
import ChatPanel from '../components/ChatPanel.jsx'

const TABS = [
  { key: 'profile', label: 'Profil' },
  { key: 'orders', label: 'Meine Bestellungen' },
  { key: 'chats', label: 'Meine Chats' },
  { key: 'history', label: 'Kaufhistorie' },
  { key: 'reviews', label: 'Bewertungen' },
  { key: 'settings', label: 'Einstellungen' },
]

const STATUS_STYLE = {
  'New Order': 'badge-muted',
  'Accepted': 'badge-success',
  'In Progress': '',
  'Completed': 'badge-success',
  'Declined': 'badge-danger',
  'Archived': 'badge-muted',
}

export default function Dashboard() {
  const { currentUser } = useApp()
  const [params, setParams] = useSearchParams()
  const tab = params.get('tab') || 'profile'
  if (!currentUser) return <Navigate to="/login" replace />

  return (
    <div className="container" style={{ padding: '48px 40px 80px' }}>
      <div className="eyebrow" style={{ marginBottom: 8 }}>Mitgliederbereich</div>
      <h1 style={{ fontSize: 36, marginBottom: 32 }}>Mein Konto</h1>

      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', gap: 32 }}>
        <div className="glass" style={{ padding: 12, alignSelf: 'start' }}>
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setParams({ tab: t.key })}
              style={{
                display: 'block', width: '100%', textAlign: 'left', padding: '11px 14px', marginBottom: 4,
                borderRadius: 8, border: 'none', background: tab === t.key ? 'var(--glass-strong)' : 'transparent',
                color: tab === t.key ? 'var(--gold-bright)' : 'var(--muted)', fontWeight: tab === t.key ? 700 : 500, fontSize: 13.5,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div>
          {tab === 'profile' && <ProfileTab />}
          {tab === 'orders' && <OrdersTab />}
          {tab === 'chats' && <ChatsTab />}
          {tab === 'history' && <HistoryTab />}
          {tab === 'reviews' && <ReviewsTab />}
          {tab === 'settings' && <SettingsTab />}
        </div>
      </div>
    </div>
  )
}

function ProfileTab() {
  const { currentUser } = useApp()
  return (
    <div className="glass" style={{ padding: 32 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginBottom: 24 }}>
        <div style={{ fontSize: 44 }}>{currentUser.avatar}</div>
        <div>
          <h2 style={{ fontSize: 24 }}>{currentUser.username}</h2>
          <div className="badge" style={{ marginTop: 8 }}>{currentUser.role}</div>
        </div>
      </div>
      <div style={{ fontSize: 13.5, color: 'var(--muted)' }}>
        Mitglied seit {new Date(currentUser.createdAt).toLocaleDateString('de-DE')}
      </div>
    </div>
  )
}

function OrdersTab() {
  const { orders, currentUser } = useApp()
  const mine = orders.filter((o) => o.customerId === currentUser.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
  if (mine.length === 0) return <div className="empty-state"><h3>Noch keine Bestellungen</h3></div>
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      {mine.map((o) => (
        <div key={o.id} className="glass" style={{ padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
            <div>
              <div style={{ fontWeight: 700 }}>Bestellung #{o.id.slice(-6)}</div>
              <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>{new Date(o.createdAt).toLocaleString('de-DE')}</div>
            </div>
            <span className={`badge ${STATUS_STYLE[o.status] || ''}`}>{o.status}</span>
          </div>
          {o.items.map((i) => (
            <div key={i.cardId} style={{ fontSize: 13, color: 'var(--muted)', display: 'flex', justifyContent: 'space-between', padding: '4px 0' }}>
              <span>{i.name} × {i.qty}</span>
              <span>{(i.price * i.qty).toFixed(2)} €</span>
            </div>
          ))}
          <div style={{ textAlign: 'right', fontFamily: 'var(--font-display)', fontSize: 18, color: 'var(--gold-bright)', marginTop: 8 }}>
            {o.total.toFixed(2)} €
          </div>
        </div>
      ))}
    </div>
  )
}

function ChatsTab() {
  const { chats, currentUser } = useApp()
  const mine = chats.filter((c) => c.customerId === currentUser.id && !c.archived)
  const [selected, setSelected] = useState(mine[0]?.id || null)
  const chat = chats.find((c) => c.id === selected)

  if (mine.length === 0) return <div className="empty-state"><h3>Keine aktiven Chats</h3><p>Ein Chat wird eröffnet, sobald eine Bestellung angenommen wird.</p></div>

  return (
    <div className="glass" style={{ display: 'grid', gridTemplateColumns: '240px 1fr', height: 560, overflow: 'hidden' }}>
      <div style={{ borderRight: '1px solid var(--border)', overflowY: 'auto' }}>
        {mine.map((c) => {
          const last = c.messages[c.messages.length - 1]
          return (
            <div key={c.id} onClick={() => setSelected(c.id)} style={{ padding: 16, cursor: 'pointer', borderBottom: '1px solid rgba(255,255,255,0.04)', background: selected === c.id ? 'var(--glass-strong)' : 'transparent' }}>
              <div style={{ fontWeight: 700, fontSize: 13.5 }}>Kalenski™</div>
              <div style={{ fontSize: 11.5, color: 'var(--muted)', marginTop: 4, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{last?.text}</div>
            </div>
          )
        })}
      </div>
      <ChatPanel chat={chat} asRole="customer" />
    </div>
  )
}

function HistoryTab() {
  const { orders, currentUser } = useApp()
  const completed = orders.filter((o) => o.customerId === currentUser.id && o.status === 'Completed')
  if (completed.length === 0) return <div className="empty-state"><h3>Noch keine abgeschlossenen Käufe</h3></div>
  return (
    <div className="glass" style={{ padding: 8 }}>
      {completed.map((o) => (
        <div key={o.id} style={{ padding: 16, borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13.5 }}>
            <span>Bestellung #{o.id.slice(-6)} · {new Date(o.createdAt).toLocaleDateString('de-DE')}</span>
            <span style={{ color: 'var(--gold-bright)' }}>{o.total.toFixed(2)} €</span>
          </div>
        </div>
      ))}
    </div>
  )
}

function ReviewsTab() {
  const { orders, currentUser, reviews, addReview } = useApp()
  const completed = orders.filter((o) => o.customerId === currentUser.id && o.status === 'Completed')
  const reviewed = (orderId) => reviews.find((r) => r.orderId === orderId)

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      {completed.length === 0 && <div className="empty-state"><h3>Keine abgeschlossenen Bestellungen zum Bewerten</h3></div>}
      {completed.map((o) => {
        const existing = reviewed(o.id)
        return <ReviewRow key={o.id} order={o} existing={existing} onSubmit={addReview} />
      })}
    </div>
  )
}

function ReviewRow({ order, existing, onSubmit }) {
  const [rating, setRating] = useState(5)
  const [comment, setComment] = useState('')
  if (existing) {
    return (
      <div className="glass" style={{ padding: 20 }}>
        <div style={{ marginBottom: 6 }}>Bestellung #{order.id.slice(-6)}</div>
        <div style={{ color: 'var(--gold)', marginBottom: 6 }}>{'★'.repeat(existing.rating)}{'☆'.repeat(5 - existing.rating)}</div>
        <div style={{ fontSize: 13.5, color: 'var(--muted)' }}>{existing.comment}</div>
      </div>
    )
  }
  return (
    <div className="glass" style={{ padding: 20 }}>
      <div style={{ marginBottom: 10 }}>Bestellung #{order.id.slice(-6)} bewerten</div>
      <div style={{ display: 'flex', gap: 4, marginBottom: 12, fontSize: 22, color: 'var(--gold)', cursor: 'pointer' }}>
        {[1, 2, 3, 4, 5].map((n) => (
          <span key={n} onClick={() => setRating(n)}>{n <= rating ? '★' : '☆'}</span>
        ))}
      </div>
      <textarea rows={3} value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Deine Erfahrung mit Kalenski™…" style={{ width: '100%', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, padding: 12, color: 'var(--ivory)', marginBottom: 12 }} />
      <button className="btn btn-gold btn-sm" onClick={() => onSubmit(order.id, rating, comment)}>Bewertung abschicken</button>
    </div>
  )
}

function SettingsTab() {
  const { currentUser, updateProfile } = useApp()
  const [avatar, setAvatar] = useState(currentUser.avatar)
  const [theme, setTheme] = useState(currentUser.theme || 'dark')
  const [privacy, setPrivacy] = useState(currentUser.privacy || 'public')
  const [notifOn, setNotifOn] = useState(currentUser.notificationsEnabled !== false)
  const AVATARS = ['🂠', '👑', '🐉', '🃏', '⚜️', '🎴']

  const save = () => updateProfile({ avatar, theme, privacy, notificationsEnabled: notifOn })

  return (
    <div className="glass" style={{ padding: 32, maxWidth: 480 }}>
      <div className="field">
        <label>Avatar</label>
        <div style={{ display: 'flex', gap: 10 }}>
          {AVATARS.map((a) => (
            <button key={a} onClick={() => setAvatar(a)} style={{ fontSize: 20, padding: 10, borderRadius: 8, border: `1px solid ${avatar === a ? 'var(--gold)' : 'var(--border)'}`, background: 'var(--surface-2)' }}>{a}</button>
          ))}
        </div>
      </div>
      <div className="field">
        <label>Design</label>
        <select value={theme} onChange={(e) => setTheme(e.target.value)}>
          <option value="dark">Dunkel (Standard)</option>
          <option value="darker">Tiefschwarz</option>
        </select>
      </div>
      <div className="field">
        <label>Privatsphäre</label>
        <select value={privacy} onChange={(e) => setPrivacy(e.target.value)}>
          <option value="public">Profil öffentlich sichtbar</option>
          <option value="private">Profil privat</option>
        </select>
      </div>
      <div className="field">
        <label>Benachrichtigungen</label>
        <select value={notifOn ? 'on' : 'off'} onChange={(e) => setNotifOn(e.target.value === 'on')}>
          <option value="on">Aktiviert</option>
          <option value="off">Deaktiviert</option>
        </select>
      </div>
      <button className="btn btn-gold" onClick={save}>Änderungen speichern</button>
    </div>
  )
}

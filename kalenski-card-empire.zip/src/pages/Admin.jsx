import React, { useState } from 'react'
import { useSearchParams, Navigate } from 'react-router-dom'
import { useApp } from '../context/AppContext.jsx'
import { CATEGORIES, CONDITIONS } from '../data/seed.js'
import ChatPanel from '../components/ChatPanel.jsx'

const TABS = [
  { key: 'cards', label: 'Karten verwalten' },
  { key: 'orders', label: 'Bestellungen' },
  { key: 'chats', label: 'Chats' },
  { key: 'events', label: 'Events' },
  { key: 'stats', label: 'Statistiken' },
]

export default function Admin() {
  const { currentUser } = useApp()
  const [params, setParams] = useSearchParams()
  const tab = params.get('tab') || 'cards'
  if (!currentUser) return <Navigate to="/login" replace />
  if (currentUser.role !== 'ADMIN') return <Navigate to="/" replace />

  return (
    <div className="container" style={{ padding: '48px 40px 80px' }}>
      <div className="eyebrow" style={{ marginBottom: 8 }}>Kontrollzentrum</div>
      <h1 style={{ fontSize: 36, marginBottom: 32 }}>Admin-Panel</h1>

      <div style={{ display: 'flex', gap: 10, marginBottom: 32, borderBottom: '1px solid var(--border)' }}>
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setParams({ tab: t.key })}
            style={{
              padding: '12px 18px', background: 'none', border: 'none', borderBottom: tab === t.key ? '2px solid var(--gold)' : '2px solid transparent',
              color: tab === t.key ? 'var(--gold-bright)' : 'var(--muted)', fontWeight: 700, fontSize: 13.5,
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'cards' && <CardsTab />}
      {tab === 'orders' && <OrdersTab />}
      {tab === 'chats' && <ChatsTab />}
      {tab === 'events' && <EventsTab />}
      {tab === 'stats' && <StatsTab />}
    </div>
  )
}

function emptyCard() {
  return { name: '', category: CATEGORIES[0], condition: CONDITIONS[0], price: '', stock: '', description: '', image: '' }
}

function CardsTab() {
  const { cards, addCard, updateCard, deleteCard } = useApp()
  const [form, setForm] = useState(emptyCard())
  const [editingId, setEditingId] = useState(null)

  const submit = (e) => {
    e.preventDefault()
    const payload = { ...form, price: Number(form.price), stock: Number(form.stock) }
    if (editingId) { updateCard(editingId, payload); setEditingId(null) } else { addCard(payload) }
    setForm(emptyCard())
  }

  const edit = (c) => {
    setEditingId(c.id)
    setForm({ name: c.name, category: c.category, condition: c.condition, price: c.price, stock: c.stock, description: c.description, image: c.image })
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '380px 1fr', gap: 32 }}>
      <form onSubmit={submit} className="glass" style={{ padding: 24, alignSelf: 'start' }}>
        <h4 style={{ marginBottom: 18 }}>{editingId ? 'Karte bearbeiten' : 'Neue Karte hinzufügen'}</h4>
        <div className="field"><label>Name</label><input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
        <div className="field"><label>Kategorie</label>
          <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
            {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="field"><label>Zustand</label>
          <select value={form.condition} onChange={(e) => setForm({ ...form, condition: e.target.value })}>
            {CONDITIONS.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          <div className="field" style={{ flex: 1 }}><label>Preis (€)</label><input required type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} /></div>
          <div className="field" style={{ flex: 1 }}><label>Lagerbestand</label><input required type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} /></div>
        </div>
        <div className="field"><label>Bild-URL</label><input required value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} /></div>
        <div className="field"><label>Beschreibung</label><textarea required rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn btn-gold" type="submit" style={{ flex: 1 }}>{editingId ? 'Speichern' : 'Hinzufügen'}</button>
          {editingId && <button type="button" className="btn btn-ghost" onClick={() => { setEditingId(null); setForm(emptyCard()) }}>Abbrechen</button>}
        </div>
      </form>

      <div className="glass" style={{ padding: 8 }}>
        {cards.map((c) => (
          <div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 14, borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
            <img src={c.image} alt={c.name} style={{ width: 44, height: 44, objectFit: 'contain', background: 'var(--surface-2)', borderRadius: 6 }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 14 }}>{c.name}</div>
              <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>{c.category} · {c.condition} · Bestand: {c.stock} · Verkauft: {c.sold || 0}</div>
            </div>
            <div style={{ fontFamily: 'var(--font-display)', color: 'var(--gold-bright)', fontSize: 16, width: 90, textAlign: 'right' }}>{c.price.toFixed(2)} €</div>
            <button className="btn btn-ghost btn-sm" onClick={() => edit(c)}>Bearbeiten</button>
            <button className="btn btn-danger btn-sm" onClick={() => deleteCard(c.id)}>Löschen</button>
          </div>
        ))}
      </div>
    </div>
  )
}

const NEXT_STATUS = {
  'New Order': ['Accepted', 'Declined'],
  'Accepted': ['In Progress', 'Completed'],
  'In Progress': ['Completed'],
  'Completed': ['Archived'],
  'Declined': ['Archived'],
  'Archived': [],
}

function OrdersTab() {
  const { orders, users, setOrderStatus } = useApp()
  const sorted = [...orders].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
  if (sorted.length === 0) return <div className="empty-state"><h3>Noch keine Bestellungen</h3></div>
  return (
    <div className="glass" style={{ padding: 8 }}>
      {sorted.map((o) => {
        const customer = users.find((u) => u.id === o.customerId)
        return (
          <div key={o.id} style={{ padding: 18, borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <div>
                <div style={{ fontWeight: 700 }}>#{o.id.slice(-6)} · {customer?.username}</div>
                <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>{new Date(o.createdAt).toLocaleString('de-DE')}</div>
              </div>
              <span className="badge">{o.status}</span>
            </div>
            {o.items.map((i) => (
              <div key={i.cardId} style={{ fontSize: 12.5, color: 'var(--muted)' }}>{i.name} × {i.qty} — {(i.price * i.qty).toFixed(2)} €</div>
            ))}
            <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
              {NEXT_STATUS[o.status].map((s) => (
                <button key={s} className={`btn btn-sm ${s === 'Declined' ? 'btn-danger' : 'btn-gold'}`} onClick={() => setOrderStatus(o.id, s)}>{s}</button>
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}

function ChatsTab() {
  const { chats } = useApp()
  const active = chats.filter((c) => !c.archived)
  const [selected, setSelected] = useState(active[0]?.id || null)
  const chat = chats.find((c) => c.id === selected)

  if (active.length === 0) return <div className="empty-state"><h3>Keine aktiven Chats</h3></div>

  return (
    <div className="glass" style={{ display: 'grid', gridTemplateColumns: '260px 1fr', height: 560, overflow: 'hidden' }}>
      <div style={{ borderRight: '1px solid var(--border)', overflowY: 'auto' }}>
        {active.map((c) => (
          <div key={c.id} onClick={() => setSelected(c.id)} style={{ padding: 16, cursor: 'pointer', borderBottom: '1px solid rgba(255,255,255,0.04)', background: selected === c.id ? 'var(--glass-strong)' : 'transparent' }}>
            <div style={{ fontWeight: 700, fontSize: 13.5 }}>#{c.orderId.slice(-6)}</div>
            <div style={{ fontSize: 11.5, color: 'var(--muted)', marginTop: 4 }}>{c.messages.length} Nachrichten</div>
          </div>
        ))}
      </div>
      <ChatPanel chat={chat} asRole="admin" />
    </div>
  )
}

function EventsTab() {
  const { events, createEvent, updateEvent, deleteEvent, setEventWinner, users } = useApp()
  const [form, setForm] = useState({ title: '', prize: '', rules: '', date: '' })

  const submit = (e) => {
    e.preventDefault()
    createEvent(form)
    setForm({ title: '', prize: '', rules: '', date: '' })
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '380px 1fr', gap: 32 }}>
      <form onSubmit={submit} className="glass" style={{ padding: 24, alignSelf: 'start' }}>
        <h4 style={{ marginBottom: 18 }}>Neues Event erstellen</h4>
        <div className="field"><label>Titel</label><input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
        <div className="field"><label>Preis</label><input required value={form.prize} onChange={(e) => setForm({ ...form, prize: e.target.value })} /></div>
        <div className="field"><label>Regeln</label><textarea required rows={3} value={form.rules} onChange={(e) => setForm({ ...form, rules: e.target.value })} /></div>
        <div className="field"><label>Datum</label><input required type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></div>
        <button className="btn btn-gold" type="submit" style={{ width: '100%' }}>Event erstellen</button>
      </form>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {events.map((ev) => (
          <div key={ev.id} className="glass" style={{ padding: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <h4>{ev.title}</h4>
              <button className="btn btn-danger btn-sm" onClick={() => deleteEvent(ev.id)}>Löschen</button>
            </div>
            <div style={{ fontSize: 12.5, color: 'var(--muted)', margin: '8px 0' }}>{ev.date} · Preis: {ev.prize}</div>
            <div style={{ fontSize: 13, marginBottom: 10 }}>{ev.rules}</div>
            <div style={{ fontSize: 12.5, color: 'var(--muted)', marginBottom: 10 }}>{ev.participants.length} Teilnehmer</div>
            {ev.winner ? (
              <div className="badge badge-success">Gewinner: {users.find((u) => u.id === ev.winner)?.username}</div>
            ) : ev.participants.length > 0 ? (
              <select onChange={(e) => setEventWinner(ev.id, e.target.value)} defaultValue="">
                <option value="" disabled>Gewinner wählen…</option>
                {ev.participants.map((pid) => <option key={pid} value={pid}>{users.find((u) => u.id === pid)?.username}</option>)}
              </select>
            ) : null}
          </div>
        ))}
      </div>
    </div>
  )
}

function StatsTab() {
  const { stats } = useApp()
  const cells = [
    ['Kunden gesamt', stats.totalCustomers],
    ['Karten gelistet', stats.cardsListed],
    ['Karten verkauft', stats.cardsSold],
    ['Umsatz', `${stats.revenue.toFixed(2)} €`],
    ['Abgeschlossene Bestellungen', stats.completedOrders],
    ['Offene Bestellungen', stats.openOrders],
    ['Ø Bewertung', stats.averageRating ? stats.averageRating.toFixed(1) : '—'],
  ]
  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 18, marginBottom: 28 }}>
        {cells.map(([label, value]) => (
          <div key={label} className="glass" style={{ padding: 22 }}>
            <div style={{ fontSize: 11, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>{label}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, color: 'var(--gold-bright)' }}>{value}</div>
          </div>
        ))}
      </div>
      <div className="glass" style={{ padding: 24 }}>
        <h4 style={{ marginBottom: 16 }}>Beliebteste Karten</h4>
        {stats.mostPopular.length === 0 && <div style={{ color: 'var(--muted)', fontSize: 13 }}>Noch keine Verkäufe.</div>}
        {stats.mostPopular.map(([name, qty], i) => (
          <div key={name} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
            <span>{i + 1}. {name}</span>
            <span style={{ color: 'var(--gold-bright)' }}>{qty} verkauft</span>
          </div>
        ))}
      </div>
    </div>
  )
}

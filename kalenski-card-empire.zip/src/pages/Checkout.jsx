import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext.jsx'

export default function Checkout() {
  const { cart, cards, placeOrder, currentUser } = useApp()
  const navigate = useNavigate()
  const [placing, setPlacing] = useState(false)
  const [done, setDone] = useState(null)

  const lines = cart.map((i) => ({ ...i, card: cards.find((c) => c.id === i.cardId) })).filter((l) => l.card)
  const total = lines.reduce((s, l) => s + l.card.price * l.qty, 0)

  if (!currentUser) { navigate('/login'); return null }

  const confirm = () => {
    setPlacing(true)
    const res = placeOrder()
    setPlacing(false)
    if (res.ok) setDone(res.order)
  }

  if (done) {
    return (
      <div className="container" style={{ padding: '80px 40px', maxWidth: 600 }}>
        <div className="glass" style={{ padding: 40, textAlign: 'center' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>👑</div>
          <h2 style={{ marginBottom: 10 }}>Bestellung aufgegeben</h2>
          <p style={{ color: 'var(--muted)', fontSize: 14, marginBottom: 24 }}>
            Deine Bestellung <b style={{ color: 'var(--gold)' }}>#{done.id.slice(-6)}</b> wurde an Kalenski™ übermittelt und wartet auf Bestätigung.
          </p>
          <button className="btn btn-gold" onClick={() => navigate('/dashboard?tab=orders')}>Meine Bestellungen ansehen</button>
        </div>
      </div>
    )
  }

  if (lines.length === 0) {
    return <div className="container" style={{ padding: '80px 40px' }}><div className="empty-state"><h3>Dein Warenkorb ist leer</h3></div></div>
  }

  return (
    <div className="container" style={{ padding: '48px 40px 80px', maxWidth: 700 }}>
      <div className="eyebrow" style={{ marginBottom: 8 }}>Letzter Schritt</div>
      <h1 style={{ fontSize: 36, marginBottom: 32 }}>Kasse</h1>

      <div className="glass" style={{ padding: 24, marginBottom: 24 }}>
        <h4 style={{ marginBottom: 16 }}>Bestellübersicht</h4>
        {lines.map((l) => (
          <div key={l.cardId} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', fontSize: 14, borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
            <span>{l.card.name} × {l.qty}</span>
            <span style={{ color: 'var(--gold-bright)' }}>{(l.card.price * l.qty).toFixed(2)} €</span>
          </div>
        ))}
        <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 16, fontSize: 18, fontFamily: 'var(--font-display)' }}>
          <span>Gesamt</span>
          <span style={{ color: 'var(--gold-bright)' }}>{total.toFixed(2)} €</span>
        </div>
      </div>

      <div className="glass" style={{ padding: 24, marginBottom: 28 }}>
        <h4 style={{ marginBottom: 10 }}>Verkäufer</h4>
        <p style={{ color: 'var(--muted)', fontSize: 13.5 }}>Alle Artikel werden direkt von <b style={{ color: 'var(--gold)' }}>Kalenski™</b> verkauft und versendet. Nach Annahme der Bestellung wird automatisch ein privater Chat eröffnet.</p>
      </div>

      <button className="btn btn-gold" style={{ width: '100%' }} disabled={placing} onClick={confirm}>
        {placing ? 'Wird verarbeitet…' : 'Bestellung verbindlich aufgeben'}
      </button>
    </div>
  )
}

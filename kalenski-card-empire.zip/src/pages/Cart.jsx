import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext.jsx'

export default function Cart() {
  const { cart, cards, updateCartQty, removeFromCart, currentUser } = useApp()
  const navigate = useNavigate()

  const lines = cart.map((i) => ({ ...i, card: cards.find((c) => c.id === i.cardId) })).filter((l) => l.card)
  const total = lines.reduce((s, l) => s + l.card.price * l.qty, 0)

  if (!currentUser) {
    return (
      <div className="container" style={{ padding: '80px 40px' }}>
        <div className="empty-state"><h3>Bitte melde dich an</h3><Link to="/login" className="btn btn-gold" style={{ marginTop: 16 }}>Zur Anmeldung</Link></div>
      </div>
    )
  }

  return (
    <div className="container" style={{ padding: '48px 40px 80px', maxWidth: 900 }}>
      <div className="eyebrow" style={{ marginBottom: 8 }}>Dein Auswahlkorb</div>
      <h1 style={{ fontSize: 38, marginBottom: 32 }}>Warenkorb</h1>

      {lines.length === 0 ? (
        <div className="empty-state">
          <h3>Dein Warenkorb ist leer</h3>
          <Link to="/" className="btn btn-gold" style={{ marginTop: 16 }}>Zum Marktplatz</Link>
        </div>
      ) : (
        <>
          <div className="glass" style={{ padding: 8, marginBottom: 24 }}>
            {lines.map((l) => (
              <div key={l.cardId} style={styles.row}>
                <img src={l.card.image} alt={l.card.name} style={styles.thumb} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 15 }}>{l.card.name}</div>
                  <div style={{ fontSize: 12.5, color: 'var(--muted)' }}>{l.card.condition} · {l.card.price.toFixed(2)} €</div>
                </div>
                <input
                  type="number" min="1" max={l.card.stock} value={l.qty}
                  onChange={(e) => updateCartQty(l.cardId, Math.max(1, Math.min(l.card.stock, Number(e.target.value))))}
                  style={styles.qtyInput}
                />
                <div style={{ width: 90, textAlign: 'right', fontFamily: 'var(--font-display)', fontSize: 17, color: 'var(--gold-bright)' }}>
                  {(l.card.price * l.qty).toFixed(2)} €
                </div>
                <button className="btn btn-danger btn-sm" onClick={() => removeFromCart(l.cardId)}>Entfernen</button>
              </div>
            ))}
          </div>
          <div className="glass" style={styles.summary}>
            <div>
              <div style={{ fontSize: 12.5, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Gesamtsumme</div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 32, color: 'var(--gold-bright)' }}>{total.toFixed(2)} €</div>
            </div>
            <button className="btn btn-gold" onClick={() => navigate('/checkout')}>Zur Kasse</button>
          </div>
        </>
      )}
    </div>
  )
}

const styles = {
  row: { display: 'flex', alignItems: 'center', gap: 18, padding: 14, borderBottom: '1px solid rgba(255,255,255,0.04)' },
  thumb: { width: 54, height: 54, objectFit: 'contain', background: 'var(--surface-2)', borderRadius: 8, padding: 4 },
  qtyInput: { width: 60, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 6, padding: 8, color: 'var(--ivory)', textAlign: 'center' },
  summary: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 28 },
}

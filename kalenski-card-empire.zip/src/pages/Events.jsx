import React from 'react'
import { useApp } from '../context/AppContext.jsx'

export default function Events() {
  const { events, currentUser, joinEvent, users } = useApp()

  return (
    <div className="container" style={{ padding: '48px 40px 80px' }}>
      <div className="eyebrow" style={{ marginBottom: 8 }}>Turniere & Verlosungen</div>
      <h1 style={{ fontSize: 38, marginBottom: 32 }}>Events</h1>

      {events.length === 0 ? (
        <div className="empty-state"><h3>Derzeit keine Events geplant</h3><p>Schau bald wieder vorbei.</p></div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 24 }}>
          {events.map((ev) => {
            const joined = currentUser && ev.participants.includes(currentUser.id)
            return (
              <div key={ev.id} className="glass" style={{ padding: 28 }}>
                <div className="eyebrow" style={{ marginBottom: 8 }}>{ev.date}</div>
                <h3 style={{ fontSize: 22, marginBottom: 10 }}>{ev.title}</h3>
                <div style={{ fontSize: 13.5, color: 'var(--gold-bright)', marginBottom: 12 }}>Preis: {ev.prize}</div>
                <p style={{ fontSize: 13.5, color: 'var(--muted)', lineHeight: 1.6, marginBottom: 16 }}>{ev.rules}</p>
                <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 16 }}>{ev.participants.length} Teilnehmer</div>
                {ev.winner ? (
                  <div className="badge badge-success">Gewinner: {users.find((u) => u.id === ev.winner)?.username}</div>
                ) : currentUser ? (
                  <button className="btn btn-gold btn-sm" disabled={joined} onClick={() => joinEvent(ev.id)}>
                    {joined ? 'Angemeldet' : 'Teilnehmen'}
                  </button>
                ) : (
                  <div style={{ fontSize: 12.5, color: 'var(--muted)' }}>Melde dich an, um teilzunehmen.</div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

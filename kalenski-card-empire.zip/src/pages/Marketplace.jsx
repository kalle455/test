import React, { useMemo, useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import { CATEGORIES, CONDITIONS } from '../data/seed.js'
import CardItem from '../components/CardItem.jsx'
import CardModal from '../components/CardModal.jsx'

const SORTS = {
  newest: (a, b) => new Date(b.uploadDate) - new Date(a.uploadDate),
  oldest: (a, b) => new Date(a.uploadDate) - new Date(b.uploadDate),
  price_asc: (a, b) => a.price - b.price,
  price_desc: (a, b) => b.price - a.price,
  alpha: (a, b) => a.name.localeCompare(b.name),
}

export default function Marketplace() {
  const { cards } = useApp()
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('Alle')
  const [condition, setCondition] = useState('Alle')
  const [sort, setSort] = useState('newest')
  const [active, setActive] = useState(null)

  const filtered = useMemo(() => {
    return cards
      .filter((c) => c.name.toLowerCase().includes(query.toLowerCase()))
      .filter((c) => category === 'Alle' || c.category === category)
      .filter((c) => condition === 'Alle' || c.condition === condition)
      .filter((c) => c.stock > 0)
      .sort(SORTS[sort])
  }, [cards, query, category, condition, sort])

  return (
    <div className="container" style={{ padding: '48px 40px 80px' }}>
      <div style={{ marginBottom: 40 }}>
        <div className="eyebrow" style={{ marginBottom: 10 }}>Kuratierte Sammlung</div>
        <h1 style={{ fontSize: 46, marginBottom: 12 }}>Der Marktplatz</h1>
        <p style={{ color: 'var(--muted)', maxWidth: 560, fontSize: 15, lineHeight: 1.6 }}>
          Jede Karte in diesem Katalog wird direkt von Kalenski™ verkauft und geprüft. Kein Zwischenhändler, keine Drittanbieter — nur authentische Stücke aus einer Hand.
        </p>
      </div>

      <div className="glass" style={styles.toolbar}>
        <input
          type="text"
          placeholder="Karte suchen…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          style={styles.search}
        />
        <select value={category} onChange={(e) => setCategory(e.target.value)} style={styles.select}>
          <option>Alle</option>
          {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
        </select>
        <select value={condition} onChange={(e) => setCondition(e.target.value)} style={styles.select}>
          <option>Alle</option>
          {CONDITIONS.map((c) => <option key={c}>{c}</option>)}
        </select>
        <select value={sort} onChange={(e) => setSort(e.target.value)} style={styles.select}>
          <option value="newest">Neueste zuerst</option>
          <option value="oldest">Älteste zuerst</option>
          <option value="price_asc">Preis aufsteigend</option>
          <option value="price_desc">Preis absteigend</option>
          <option value="alpha">Alphabetisch</option>
        </select>
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state">
          <h3>Keine Karten gefunden</h3>
          <p>Passe deine Suche oder Filter an.</p>
        </div>
      ) : (
        <div style={styles.grid}>
          {filtered.map((card) => (
            <CardItem key={card.id} card={card} onOpen={setActive} />
          ))}
        </div>
      )}

      <CardModal card={active} onClose={() => setActive(null)} />
    </div>
  )
}

const styles = {
  toolbar: { display: 'flex', gap: 14, padding: 20, marginBottom: 36 },
  search: { flex: 1, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, padding: '11px 16px', color: 'var(--ivory)', fontSize: 14, outline: 'none' },
  select: { background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, padding: '11px 14px', color: 'var(--ivory)', fontSize: 13.5, outline: 'none' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 24 },
}

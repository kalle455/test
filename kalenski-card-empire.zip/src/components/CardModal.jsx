import React, { useState } from 'react'
import { useApp } from '../context/AppContext.jsx'

export default function CardModal({ card, onClose }) {
  const { currentUser, addToCart } = useApp()
  const [qty, setQty] = useState(1)
  if (!card) return null
  const outOfStock = card.stock <= 0

  return (
    <div style={styles.overlay} onClick={onClose}>
      <div className="glass" style={styles.modal} onClick={(e) => e.stopPropagation()}>
        <button style={styles.close} onClick={onClose}>✕</button>
        <div style={styles.grid}>
          <div style={styles.imageWrap}>
            <img src={card.image} alt={card.name} style={styles.image} />
          </div>
          <div>
            <div className="badge badge-muted" style={{ marginBottom: 10 }}>{card.category} · {card.condition}</div>
            <h2 style={{ fontSize: 30, marginBottom: 10 }}>{card.name}</h2>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 26, color: 'var(--gold-bright)', marginBottom: 16 }}>
              {card.price.toFixed(2)} €
            </div>
            <p style={{ color: 'var(--muted)', lineHeight: 1.6, fontSize: 14, marginBottom: 20 }}>{card.description}</p>
            <div style={{ display: 'flex', gap: 20, fontSize: 12.5, color: 'var(--muted)', marginBottom: 24 }}>
              <span>Lagerbestand: <b style={{ color: 'var(--ivory)' }}>{card.stock}</b></span>
              <span>Verkauft: <b style={{ color: 'var(--ivory)' }}>{card.sold || 0}</b></span>
              <span>Eingestellt am: <b style={{ color: 'var(--ivory)' }}>{new Date(card.uploadDate).toLocaleDateString('de-DE')}</b></span>
            </div>
            {!outOfStock && currentUser && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <input
                  type="number" min="1" max={card.stock} value={qty}
                  onChange={(e) => setQty(Math.max(1, Math.min(card.stock, Number(e.target.value))))}
                  style={{ width: 70, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 6, padding: 10, color: 'var(--ivory)' }}
                />
                <button className="btn btn-gold" onClick={() => { addToCart(card.id, qty); onClose() }}>In den Warenkorb</button>
              </div>
            )}
            {outOfStock && <div className="badge badge-danger">Ausverkauft</div>}
            {!currentUser && <div style={{ color: 'var(--muted)', fontSize: 13 }}>Melde dich an, um diese Karte zu kaufen.</div>}
          </div>
        </div>
      </div>
    </div>
  )
}

const styles = {
  overlay: { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 },
  modal: { position: 'relative', width: 820, maxWidth: '90vw', padding: 36, background: 'var(--surface)' },
  close: { position: 'absolute', top: 16, right: 16, background: 'transparent', border: 'none', color: 'var(--muted)', fontSize: 18 },
  grid: { display: 'grid', gridTemplateColumns: '280px 1fr', gap: 36 },
  imageWrap: { background: 'var(--surface-2)', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', height: 340 },
  image: { width: '100%', height: '100%', objectFit: 'contain', padding: 16 },
}

import React, { useState, useRef, useEffect } from 'react'
import { useApp } from '../context/AppContext.jsx'

export default function ChatPanel({ chat, asRole }) {
  const { sendMessage, archiveChat, currentUser, users } = useApp()
  const [text, setText] = useState('')
  const endRef = useRef(null)

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [chat?.messages?.length])

  if (!chat) return <div className="empty-state"><h3>Kein Chat ausgewählt</h3><p>Wähle links eine Unterhaltung aus.</p></div>

  const customer = users.find((u) => u.id === chat.customerId)
  const mySenderKey = asRole === 'admin' ? 'admin' : 'customer'

  const submit = (e) => {
    e.preventDefault()
    if (!text.trim()) return
    sendMessage(chat.id, text.trim(), mySenderKey)
    setText('')
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div style={styles.head}>
        <div>
          <div style={{ fontWeight: 700 }}>{asRole === 'admin' ? customer?.username : 'Kalenski™'}</div>
          <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>Bestellung #{chat.orderId.slice(-6)}</div>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={() => archiveChat(chat.id, !chat.archived)}>
          {chat.archived ? 'Wiederherstellen' : 'Archivieren'}
        </button>
      </div>
      <div className="scrollpane" style={styles.messages}>
        {chat.messages.map((m) => {
          const mine = m.sender === mySenderKey
          const isSystem = m.sender === 'system'
          return (
            <div key={m.id} style={{ display: 'flex', justifyContent: isSystem ? 'center' : mine ? 'flex-end' : 'flex-start', marginBottom: 10 }}>
              {isSystem ? (
                <div style={styles.systemMsg}>{m.text}</div>
              ) : (
                <div style={{ ...styles.bubble, ...(mine ? styles.bubbleMine : styles.bubbleTheirs) }}>
                  {m.text}
                  <div style={styles.time}>{new Date(m.at).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}</div>
                </div>
              )}
            </div>
          )
        })}
        <div ref={endRef} />
      </div>
      <form onSubmit={submit} style={styles.inputRow}>
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Nachricht schreiben…" style={styles.input} />
        <button className="btn btn-gold btn-sm" type="submit">Senden</button>
      </form>
    </div>
  )
}

const styles = {
  head: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 18px', borderBottom: '1px solid var(--border)' },
  messages: { flex: 1, overflowY: 'auto', padding: 18 },
  bubble: { maxWidth: '70%', padding: '10px 14px', borderRadius: 12, fontSize: 13.5, lineHeight: 1.5 },
  bubbleMine: { background: 'linear-gradient(135deg, var(--gold) 0%, var(--gold-dim) 100%)', color: '#0c0a08' },
  bubbleTheirs: { background: 'var(--surface-2)', border: '1px solid var(--border)' },
  systemMsg: { fontSize: 11.5, color: 'var(--muted)', fontStyle: 'italic', textAlign: 'center' },
  time: { fontSize: 9.5, opacity: 0.65, marginTop: 4, textAlign: 'right' },
  inputRow: { display: 'flex', gap: 10, padding: 14, borderTop: '1px solid var(--border)' },
  input: { flex: 1, background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 8, padding: '10px 14px', color: 'var(--ivory)', outline: 'none' },
}

import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext.jsx'
import NotificationBell from './NotificationBell.jsx'

export default function Header() {
  const { currentUser, logout, cart } = useApp()
  const navigate = useNavigate()
  const [menuOpen, setMenuOpen] = useState(false)
  const cartCount = cart.reduce((s, i) => s + i.qty, 0)

  return (
    <header style={styles.header}>
      <div className="container" style={styles.inner}>
        <Link to="/" style={styles.brand}>
          <span style={styles.crest}>♛</span>
          <div>
            <div style={styles.brandName}>Kalenski<span style={styles.tm}>™</span></div>
            <div style={styles.brandSub}>THE ONE AND ONLY CARD EMPIRE<span style={styles.tm}>®</span></div>
          </div>
        </Link>

        <nav style={styles.nav}>
          <Link to="/" style={styles.navLink}>Marktplatz</Link>
          <Link to="/events" style={styles.navLink}>Events</Link>
          {currentUser && <Link to="/dashboard" style={styles.navLink}>Mein Konto</Link>}
          {currentUser?.role === 'ADMIN' && <Link to="/admin" style={styles.navLinkGold}>Admin</Link>}
        </nav>

        <div style={styles.actions}>
          {currentUser && (
            <>
              <NotificationBell />
              <Link to="/cart" className="btn btn-ghost btn-sm" style={{ position: 'relative' }}>
                🛒 Warenkorb
                {cartCount > 0 && <span style={styles.cartBadge}>{cartCount}</span>}
              </Link>
              <div style={styles.userMenu} onClick={() => setMenuOpen((v) => !v)}>
                <span style={styles.avatar}>{currentUser.avatar}</span>
                <span style={{ fontSize: 13.5 }}>{currentUser.username}</span>
                {menuOpen && (
                  <div className="glass" style={styles.dropdown} onMouseLeave={() => setMenuOpen(false)}>
                    <div className="badge" style={{ marginBottom: 10 }}>{currentUser.role}</div>
                    <button className="btn btn-ghost btn-sm" style={{ width: '100%' }} onClick={() => navigate('/dashboard?tab=settings')}>Einstellungen</button>
                    <button className="btn btn-danger btn-sm" style={{ width: '100%', marginTop: 8 }} onClick={() => { logout(); navigate('/') }}>Abmelden</button>
                  </div>
                )}
              </div>
            </>
          )}
          {!currentUser && <Link to="/login" className="btn btn-gold btn-sm">Anmelden</Link>}
        </div>
      </div>
      <div className="foil-rule" />
    </header>
  )
}

const styles = {
  header: { position: 'sticky', top: 0, zIndex: 50, background: 'rgba(8,7,10,0.85)', backdropFilter: 'blur(14px)' },
  inner: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 84 },
  brand: { display: 'flex', alignItems: 'center', gap: 12 },
  crest: { fontSize: 28, color: 'var(--gold)' },
  brandName: { fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: 'var(--ivory)', lineHeight: 1 },
  brandSub: { fontSize: 9.5, letterSpacing: '0.18em', color: 'var(--gold)', marginTop: 4 },
  tm: { fontSize: '0.55em', verticalAlign: 'super' },
  nav: { display: 'flex', gap: 32 },
  navLink: { fontSize: 13.5, color: 'var(--muted)', fontWeight: 600, letterSpacing: '0.02em' },
  navLinkGold: { fontSize: 13.5, color: 'var(--gold)', fontWeight: 700, letterSpacing: '0.02em' },
  actions: { display: 'flex', alignItems: 'center', gap: 12 },
  cartBadge: { position: 'absolute', top: -6, right: -6, background: 'var(--gold)', color: '#0c0a08', borderRadius: '50%', width: 18, height: 18, fontSize: 10, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center' },
  userMenu: { position: 'relative', display: 'flex', alignItems: 'center', gap: 8, padding: '6px 12px', borderRadius: 8, border: '1px solid var(--border)', cursor: 'pointer' },
  avatar: { fontSize: 16 },
  dropdown: { position: 'absolute', top: 46, right: 0, width: 190, padding: 14, zIndex: 60 },
}

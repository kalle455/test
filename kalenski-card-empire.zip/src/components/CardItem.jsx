import React from 'react'
import { useApp } from '../context/AppContext.jsx'

export default function CardItem({ card, onOpen }) {
  const { currentUser, addToCart, toggleWishlist } = useApp()
  const isWishlisted = currentUser?.wishlist?.includes(card.id)
  const outOfStock = card.stock <= 0

  return (
    <div className="glass" style={styles.card} onClick={() => onOpen(card)}>
      <div style={styles.imageWrap}>
        <img src={card.image} alt={card.name} style={styles.image} onError={(e) => { e.target.style.display = 'none' }} />
        {currentUser && (
          <button
            style={styles.wishBtn}
            onClick={(e) => { e.stopPropagation(); toggleWishlist(card.id) }}
            title="Zur Wunschliste"
          >
            {isWishlisted ? '★' : '☆'}
          </button>
        )}
        {outOfStock && <div style={styles.soldOutBadge}>Ausverkauft</div>}
      </div>
      <div style={styles.body}>
        <div className="badge badge-muted" style={{ marginBottom: 8 }}>{card.category} · {card.condition}</div>
        <h4 style={styles.name}>{card.name}</h4>
        <div style={styles.footer}>
          <span style={styles.price}>{card.price.toFixed(2)} €</span>
          <button
            className="btn btn-gold btn-sm"
            disabled={outOfStock || !currentUser}
            onClick={(e) => { e.stopPropagation(); addToCart(card.id, 1) }}
          >
            {outOfStock ? 'Vergriffen' : 'In den Warenkorb'}
          </button>
        </div>
      </div>
    </div>
  )
}

const styles = {
  card: { display: 'flex', flexDirection: 'column', cursor: 'pointer', overflow: 'hidden', transition: 'transform 0.18s ease' },
  imageWrap: { position: 'relative', height: 220, background: 'var(--surface-2)', display: 'flex', alignItems: 'center', justifyContent: 'center' },
  image: { width: '100%', height: '100%', objectFit: 'contain', padding: 12 },
  wishBtn: { position: 'absolute', top: 10, right: 10, background: 'rgba(8,7,10,0.6)', border: '1px solid var(--border)', borderRadius: '50%', width: 32, height: 32, color: 'var(--gold-bright)', fontSize: 16 },
  soldOutBadge: { position: 'absolute', bottom: 10, left: 10, background: 'rgba(181,73,63,0.85)', color: '#fff', fontSize: 10.5, fontWeight: 700, letterSpacing: '0.05em', padding: '4px 10px', borderRadius: 4, textTransform: 'uppercase' },
  body: { padding: '16px 16px 18px' },
  name: { fontSize: 17, marginBottom: 10 },
  footer: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 },
  price: { fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: 'var(--gold-bright)' },
}

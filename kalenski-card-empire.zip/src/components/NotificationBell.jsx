import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext.jsx'

export default function NotificationBell() {
  const { notifications, currentUser, markNotificationRead, markAllNotificationsRead } = useApp()
  const [open, setOpen] = useState(false)
  const navigate = useNavigate()
  const mine = notifications.filter((n) => n.userId === currentUser?.id)
  const unread = mine.filter((n) => !n.read).length

  return (
    <div style={{ position: 'relative' }}>
      <button className="btn btn-ghost btn-sm" onClick={() => setOpen((v) => !v)} style={{ position: 'relative' }}>
        🔔
        {unread > 0 && <span style={styles.dot}>{unread}</span>}
      </button>
      {open && (
        <div className="glass scrollpane" style={styles.panel} onMouseLeave={() => setOpen(false)}>
          <div style={styles.panelHeader}>
            <span style={{ fontWeight: 700, fontSize: 13.5 }}>Benachrichtigungen</span>
            {unread > 0 && <button className="btn btn-ghost btn-sm" onClick={markAllNotificationsRead}>Alle gelesen</button>}
          </div>
          {mine.length === 0 && <div style={{ padding: 20, color: 'var(--muted)', fontSize: 13 }}>Keine Benachrichtigungen.</div>}
          {mine.slice(0, 12).map((n) => (
            <div
              key={n.id}
              style={{ ...styles.item, opacity: n.read ? 0.55 : 1 }}
              onClick={() => { markNotificationRead(n.id); if (n.link) navigate(n.link); setOpen(false) }}
            >
              <div className="badge badge-muted" style={{ marginBottom: 4 }}>{n.type}</div>
              <div style={{ fontSize: 13 }}>{n.message}</div>
              <div style={{ fontSize: 10.5, color: 'var(--muted)', marginTop: 2 }}>{new Date(n.createdAt).toLocaleString('de-DE')}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

const styles = {
  dot: { position: 'absolute', top: -4, right: -4, background: 'var(--danger)', color: '#fff', borderRadius: '50%', width: 16, height: 16, fontSize: 9.5, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800 },
  panel: { position: 'absolute', top: 46, right: 0, width: 320, maxHeight: 420, overflowY: 'auto', zIndex: 60 },
  panelHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderBottom: '1px solid var(--border)' },
  item: { padding: '12px 16px', borderBottom: '1px solid rgba(255,255,255,0.04)', cursor: 'pointer' },
}

import React from 'react'

export default function Footer() {
  return (
    <footer style={{ marginTop: 'auto' }}>
      <div className="foil-rule" />
      <div className="container" style={{ padding: '32px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, color: 'var(--gold)' }}>
          Kalenski<span style={{ fontSize: '0.6em', verticalAlign: 'super' }}>™</span> | The ONE AND ONLY Card Empire<span style={{ fontSize: '0.6em', verticalAlign: 'super' }}>®</span>
        </div>
        <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>© {new Date().getFullYear()} Kalenski™ — Alle Rechte vorbehalten.</div>
      </div>
    </footer>
  )
}

import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react'
import { seedCards } from '../data/seed.js'

const AppContext = createContext(null)

const KEYS = {
  users: 'kalenski_users',
  currentUser: 'kalenski_currentUser',
  cards: 'kalenski_cards',
  orders: 'kalenski_orders',
  chats: 'kalenski_chats',
  reviews: 'kalenski_reviews',
  events: 'kalenski_events',
  notifications: 'kalenski_notifications',
  carts: 'kalenski_carts',
}

function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key)
    return raw ? JSON.parse(raw) : fallback
  } catch {
    return fallback
  }
}

function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value))
}

function uid(prefix = 'id') {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

const ROLES = ['Customer', 'Stammkunde', 'VIP', 'POTM', 'ADMIN']

export function AppProvider({ children }) {
  const [users, setUsers] = useState(() => {
    const existing = load(KEYS.users, null)
    if (existing && existing.length) return existing
    const seedUsers = [
      { id: 'user-kalenski', username: 'Kalenski', role: 'ADMIN', avatar: '👑', createdAt: new Date().toISOString(), theme: 'dark', privacy: 'public' },
    ]
    save(KEYS.users, seedUsers)
    return seedUsers
  })

  const [cards, setCards] = useState(() => load(KEYS.cards, seedCards))
  const [orders, setOrders] = useState(() => load(KEYS.orders, []))
  const [chats, setChats] = useState(() => load(KEYS.chats, []))
  const [reviews, setReviews] = useState(() => load(KEYS.reviews, []))
  const [events, setEvents] = useState(() => load(KEYS.events, []))
  const [notifications, setNotifications] = useState(() => load(KEYS.notifications, []))
  const [carts, setCarts] = useState(() => load(KEYS.carts, {}))
  const [currentUserId, setCurrentUserId] = useState(() => load(KEYS.currentUser, null))

  useEffect(() => save(KEYS.users, users), [users])
  useEffect(() => save(KEYS.cards, cards), [cards])
  useEffect(() => save(KEYS.orders, orders), [orders])
  useEffect(() => save(KEYS.chats, chats), [chats])
  useEffect(() => save(KEYS.reviews, reviews), [reviews])
  useEffect(() => save(KEYS.events, events), [events])
  useEffect(() => save(KEYS.notifications, notifications), [notifications])
  useEffect(() => save(KEYS.carts, carts), [carts])
  useEffect(() => save(KEYS.currentUser, currentUserId), [currentUserId])

  const currentUser = useMemo(
    () => users.find((u) => u.id === currentUserId) || null,
    [users, currentUserId]
  )

  const cart = carts[currentUserId] || []

  const notify = useCallback((userId, type, message, link = null) => {
    setNotifications((prev) => [
      { id: uid('notif'), userId, type, message, link, read: false, createdAt: new Date().toISOString() },
      ...prev,
    ])
  }, [])

  // ---------- AUTH ----------
  const login = useCallback((username) => {
    const clean = username.trim()
    if (!clean) return { ok: false, error: 'Bitte einen Benutzernamen eingeben.' }
    let user = users.find((u) => u.username.toLowerCase() === clean.toLowerCase())
    if (!user) {
      user = {
        id: uid('user'),
        username: clean,
        role: 'Customer',
        avatar: '🂠',
        createdAt: new Date().toISOString(),
        theme: 'dark',
        privacy: 'public',
      }
      setUsers((prev) => [...prev, user])
    }
    setCurrentUserId(user.id)
    return { ok: true, user }
  }, [users])

  const logout = useCallback(() => setCurrentUserId(null), [])

  const updateProfile = useCallback((patch) => {
    setUsers((prev) => prev.map((u) => (u.id === currentUserId ? { ...u, ...patch } : u)))
  }, [currentUserId])

  // ---------- CARDS (admin) ----------
  const addCard = useCallback((card) => {
    setCards((prev) => [
      { ...card, id: uid('card'), uploadDate: new Date().toISOString(), sold: 0 },
      ...prev,
    ])
  }, [])

  const updateCard = useCallback((id, patch) => {
    setCards((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c)))
  }, [])

  const deleteCard = useCallback((id) => {
    setCards((prev) => prev.filter((c) => c.id !== id))
  }, [])

  // ---------- CART ----------
  const setCartFor = useCallback((userId, updater) => {
    setCarts((prev) => ({ ...prev, [userId]: updater(prev[userId] || []) }))
  }, [])

  const addToCart = useCallback((cardId, qty = 1) => {
    if (!currentUserId) return
    setCartFor(currentUserId, (items) => {
      const existing = items.find((i) => i.cardId === cardId)
      if (existing) {
        return items.map((i) => (i.cardId === cardId ? { ...i, qty: i.qty + qty } : i))
      }
      return [...items, { cardId, qty }]
    })
  }, [currentUserId, setCartFor])

  const updateCartQty = useCallback((cardId, qty) => {
    if (!currentUserId) return
    setCartFor(currentUserId, (items) =>
      qty <= 0 ? items.filter((i) => i.cardId !== cardId) : items.map((i) => (i.cardId === cardId ? { ...i, qty } : i))
    )
  }, [currentUserId, setCartFor])

  const removeFromCart = useCallback((cardId) => {
    if (!currentUserId) return
    setCartFor(currentUserId, (items) => items.filter((i) => i.cardId !== cardId))
  }, [currentUserId, setCartFor])

  const clearCart = useCallback(() => {
    if (!currentUserId) return
    setCartFor(currentUserId, () => [])
  }, [currentUserId, setCartFor])

  // ---------- WISHLIST ----------
  const toggleWishlist = useCallback((cardId) => {
    if (!currentUserId) return
    setUsers((prev) => prev.map((u) => {
      if (u.id !== currentUserId) return u
      const wishlist = u.wishlist || []
      const has = wishlist.includes(cardId)
      return { ...u, wishlist: has ? wishlist.filter((id) => id !== cardId) : [...wishlist, cardId] }
    }))
  }, [currentUserId])

  // ---------- ORDERS ----------
  const placeOrder = useCallback(() => {
    if (!currentUserId || cart.length === 0) return { ok: false }
    const lineItems = cart.map((i) => {
      const card = cards.find((c) => c.id === i.cardId)
      return card ? { cardId: card.id, name: card.name, price: card.price, qty: i.qty } : null
    }).filter(Boolean)
    const total = lineItems.reduce((sum, li) => sum + li.price * li.qty, 0)
    const order = {
      id: uid('order'),
      customerId: currentUserId,
      seller: 'Kalenski™',
      items: lineItems,
      total,
      status: 'New Order',
      statusHistory: [{ status: 'New Order', at: new Date().toISOString() }],
      createdAt: new Date().toISOString(),
    }
    setOrders((prev) => [order, ...prev])
    clearCart()
    const admin = users.find((u) => u.role === 'ADMIN')
    if (admin) notify(admin.id, 'New Order', `Neue Bestellung von ${currentUser?.username}.`, `/admin?tab=orders`)
    return { ok: true, order }
  }, [currentUserId, cart, cards, users, currentUser, clearCart, notify])

  const setOrderStatus = useCallback((orderId, status) => {
    setOrders((prev) => prev.map((o) => {
      if (o.id !== orderId) return o
      const updated = { ...o, status, statusHistory: [...o.statusHistory, { status, at: new Date().toISOString() }] }
      return updated
    }))

    setOrders((prevAfter) => {
      const order = prevAfter.find((o) => o.id === orderId)
      if (!order) return prevAfter
      if (status === 'Accepted') {
        // deduct stock
        setCards((prevCards) => prevCards.map((c) => {
          const li = order.items.find((i) => i.cardId === c.id)
          return li ? { ...c, stock: Math.max(0, c.stock - li.qty), sold: (c.sold || 0) + li.qty } : c
        }))
        // create chat if not exists
        setChats((prevChats) => {
          if (prevChats.some((ch) => ch.orderId === orderId)) return prevChats
          return [
            {
              id: uid('chat'),
              orderId,
              customerId: order.customerId,
              archived: false,
              messages: [{
                id: uid('msg'), sender: 'system', text: `Bestellung ${orderId} wurde angenommen. Chat mit Kalenski™ eröffnet.`, at: new Date().toISOString(),
              }],
            },
            ...prevChats,
          ]
        })
        notify(order.customerId, 'Order Accepted', 'Deine Bestellung wurde angenommen. Der Chat ist jetzt offen.', '/dashboard?tab=chats')
      }
      if (status === 'Declined') {
        notify(order.customerId, 'Order Declined', 'Deine Bestellung wurde leider abgelehnt.', '/dashboard?tab=orders')
      }
      if (status === 'Completed') {
        notify(order.customerId, 'Review Request', 'Bestellung abgeschlossen — hinterlasse eine Bewertung für Kalenski™.', '/dashboard?tab=reviews')
      }
      return prevAfter
    })
  }, [notify])

  // ---------- CHAT ----------
  const sendMessage = useCallback((chatId, text, sender) => {
    setChats((prev) => prev.map((ch) => {
      if (ch.id !== chatId) return ch
      return { ...ch, messages: [...ch.messages, { id: uid('msg'), sender, text, at: new Date().toISOString() }] }
    }))
    const chat = chats.find((c) => c.id === chatId)
    if (chat) {
      const admin = users.find((u) => u.role === 'ADMIN')
      const recipient = sender === 'admin' ? chat.customerId : admin?.id
      if (recipient) notify(recipient, 'New Chat Message', 'Neue Nachricht erhalten.', '/dashboard?tab=chats')
    }
  }, [chats, users, notify])

  const archiveChat = useCallback((chatId, archived = true) => {
    setChats((prev) => prev.map((ch) => (ch.id === chatId ? { ...ch, archived } : ch)))
  }, [])

  // ---------- REVIEWS ----------
  const addReview = useCallback((orderId, rating, comment) => {
    if (!currentUserId) return
    if (reviews.some((r) => r.orderId === orderId)) return
    setReviews((prev) => [
      { id: uid('review'), orderId, customerId: currentUserId, rating, comment, createdAt: new Date().toISOString() },
      ...prev,
    ])
  }, [currentUserId, reviews])

  // ---------- EVENTS ----------
  const createEvent = useCallback((event) => {
    setEvents((prev) => [
      { ...event, id: uid('event'), participants: [], winner: null, createdAt: new Date().toISOString() },
      ...prev,
    ])
  }, [])

  const updateEvent = useCallback((id, patch) => {
    setEvents((prev) => prev.map((e) => (e.id === id ? { ...e, ...patch } : e)))
  }, [])

  const deleteEvent = useCallback((id) => {
    setEvents((prev) => prev.filter((e) => e.id !== id))
  }, [])

  const joinEvent = useCallback((eventId) => {
    if (!currentUserId) return
    setEvents((prev) => prev.map((e) => {
      if (e.id !== eventId) return e
      if (e.participants.includes(currentUserId)) return e
      return { ...e, participants: [...e.participants, currentUserId] }
    }))
  }, [currentUserId])

  const setEventWinner = useCallback((eventId, winnerId) => {
    setEvents((prev) => prev.map((e) => (e.id === eventId ? { ...e, winner: winnerId } : e)))
    const event = events.find((e) => e.id === eventId)
    if (event) notify(winnerId, 'New Event', `Herzlichen Glückwunsch! Du hast das Event "${event.title}" gewonnen.`, '/events')
  }, [events, notify])

  // ---------- NOTIFICATIONS ----------
  const markNotificationRead = useCallback((id) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }, [])

  const markAllNotificationsRead = useCallback(() => {
    if (!currentUserId) return
    setNotifications((prev) => prev.map((n) => (n.userId === currentUserId ? { ...n, read: true } : n)))
  }, [currentUserId])

  // low stock watcher — notify admin once per threshold cross using a ref so
  // it survives re-renders without mutating card objects
  const notifiedStockRef = React.useRef(new Set())
  useEffect(() => {
    const admin = users.find((u) => u.role === 'ADMIN')
    if (!admin) return
    cards.forEach((c) => {
      if (c.stock === 0 && !notifiedStockRef.current.has(`out:${c.id}`)) {
        notifiedStockRef.current.add(`out:${c.id}`)
        notify(admin.id, 'Out of Stock', `${c.name} ist ausverkauft.`)
      } else if (c.stock > 0 && c.stock <= 2 && !notifiedStockRef.current.has(`low:${c.id}`)) {
        notifiedStockRef.current.add(`low:${c.id}`)
        notify(admin.id, 'Low Stock', `${c.name} hat nur noch ${c.stock} Stück auf Lager.`)
      } else if (c.stock > 2) {
        notifiedStockRef.current.delete(`low:${c.id}`)
        notifiedStockRef.current.delete(`out:${c.id}`)
      }
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cards.map((c) => `${c.id}:${c.stock}`).join(',')])

  // ---------- STATS ----------
  const stats = useMemo(() => {
    const completedOrders = orders.filter((o) => o.status === 'Completed')
    const openOrders = orders.filter((o) => ['New Order', 'Accepted', 'In Progress'].includes(o.status))
    const revenue = completedOrders.reduce((sum, o) => sum + o.total, 0)
    const cardsSold = cards.reduce((sum, c) => sum + (c.sold || 0), 0)
    const avgRating = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0
    const popularity = {}
    orders.forEach((o) => o.items.forEach((i) => { popularity[i.name] = (popularity[i.name] || 0) + i.qty }))
    const mostPopular = Object.entries(popularity).sort((a, b) => b[1] - a[1]).slice(0, 5)
    return {
      totalCustomers: users.filter((u) => u.role !== 'ADMIN').length,
      cardsListed: cards.length,
      cardsSold,
      revenue,
      completedOrders: completedOrders.length,
      openOrders: openOrders.length,
      mostPopular,
      averageRating: avgRating,
    }
  }, [orders, cards, users, reviews])

  const value = {
    ROLES,
    users, currentUser, currentUserId,
    login, logout, updateProfile,
    cards, addCard, updateCard, deleteCard,
    cart, addToCart, updateCartQty, removeFromCart, clearCart,
    toggleWishlist,
    orders, placeOrder, setOrderStatus,
    chats, sendMessage, archiveChat,
    reviews, addReview,
    events, createEvent, updateEvent, deleteEvent, joinEvent, setEventWinner,
    notifications, markNotificationRead, markAllNotificationsRead,
    stats,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
